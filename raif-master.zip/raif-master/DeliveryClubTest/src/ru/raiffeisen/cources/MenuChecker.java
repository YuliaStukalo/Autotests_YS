package ru.raiffeisen.cources;

public interface MenuChecker {
    boolean check();
}
