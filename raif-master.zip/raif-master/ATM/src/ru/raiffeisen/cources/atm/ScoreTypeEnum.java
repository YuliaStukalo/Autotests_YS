package ru.raiffeisen.cources.atm;

public enum ScoreTypeEnum {
    CREDIT,
    DEBET,
    CURRENT
}
